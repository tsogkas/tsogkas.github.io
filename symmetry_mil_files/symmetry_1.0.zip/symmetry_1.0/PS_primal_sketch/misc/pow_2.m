function res = pow_2(input);
res = input.*input;