
function res = my_sign(input);
res = sign(input) + (input==0);
