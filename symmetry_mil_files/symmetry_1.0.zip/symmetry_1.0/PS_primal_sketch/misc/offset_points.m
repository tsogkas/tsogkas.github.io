function inp = keep_points(inp,c_m,c_n);
inp.c_m = inp.c_m + c_m;
inp.c_n = inp.c_n + c_n;
